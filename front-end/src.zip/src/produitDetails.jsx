// src/produitDetails.jsx
import { useState } from 'react';
import './App.css';
import { CiShoppingBasket, CiHeart } from "react-icons/ci";
import { FiShield, FiTruck, FiRefreshCw, FiSearch } from 'react-icons/fi';
import { Link, useNavigate } from 'react-router-dom';
import { useSelector, useDispatch } from 'react-redux';
import { selectCurrentProduct, selectAllProducts, setSelectedProduct } from './redux/productSlice';
import { addToCart } from './redux/cartSlice';
import { toggleWishlist, selectIsInWishlist } from './redux/wishlistSlice';

export default function ProduitDetails() {
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const product = useSelector(selectCurrentProduct);
  const allProducts = useSelector(selectAllProducts);
  const isInWishlist = useSelector(selectIsInWishlist(product.id));

  const [selectedImg, setSelectedImg] = useState(product.images ? product.images[0] : product.img);
  const [selectedBracelet, setSelectedBracelet] = useState(product.bracelets ? product.bracelets[0] : 'Cuir');
  const [selectedColor, setSelectedColor] = useState(product.colors ? product.colors[0]?.id : '');
  const [quantity, setQuantity] = useState(1);

  const handleAddToCart = () => {
    dispatch(addToCart({
      ...product,
      qty: Number(quantity),
      bracelet: selectedBracelet
    }));
  };

  const handleBuyNow = () => {
    handleAddToCart();
    navigate('/panier');
  };

  const similarProducts = allProducts.filter(p => p.id !== product.id).slice(0, 4);

  return (
    <div>
      <section>
        <div className="container cl-pdp">
          <div className="cl-pdp-gallery">
            <div className="cl-pdp-thumbs">
              {(product.images || [product.img]).map((imgSrc, index) => (
                <button 
                  key={index} 
                  type="button"
                  className={`cl-pdp-thumb ${selectedImg === imgSrc ? 'active' : ''}`}
                  onClick={() => setSelectedImg(imgSrc)}
                >
                  <img src={imgSrc} alt="" />
                </button>
              ))}
            </div>

            <div className="cl-pdp-main">
              <span className="cl-pdp-badge">−15%</span>
              <img src={selectedImg} alt={product.name} />
              <button className="cl-pdp-zoom" aria-label="Zoomer">
                <FiSearch />
              </button>
            </div>
          </div>

          <div className="cl-pdp-info">
            <h1 className="cl-pdp-title">{product.name}</h1>

            <div className="cl-pdp-price-row">
              <span className="cl-pdp-price">{product.price.toLocaleString('fr-FR')} <span className='devise'>XOF</span></span>
            </div>

            <p className="cl-pdp-desc">
              {product.description || "Des montres pensées pour allier précision horlogère et élégance moderne."}
            </p>

            <div className="cl-pdp-reassurance">
              <div className="cl-pdp-reassurance-item">
                <FiTruck />
                <div><p>Livraison offerte</p><p>Partout au Bénin</p></div>
              </div>
              <div className="cl-pdp-reassurance-item">
                <FiRefreshCw />
                <div><p>Retour 30 jours</p><p>Simple et gratuit</p></div>
              </div>
              <div className="cl-pdp-reassurance-item">
                <FiShield />
                <div><p>Garantie 2 ans</p><p>Qualité assurée</p></div>
              </div>
            </div>

            {product.colors && product.colors.length > 0 && (
              <div className="cl-pdp-option">
                <p className="cl-pdp-option-label">Couleurs disponibles</p>
                <div className="cl-pdp-colors">
                  {product.colors.map(c => (
                    <button 
                      key={c.id}
                      type="button"
                      className={`cl-pdp-color-dot ${selectedColor === c.id ? 'active' : ''}`}
                      onClick={() => setSelectedColor(c.id)}
                    >
                      <span style={{ background: c.hex }}></span>
                    </button>
                  ))}
                </div>
              </div>
            )}

            {product.bracelets && product.bracelets.length > 0 && (
              <div className="cl-pdp-option">
                <p className="cl-pdp-option-label">Bracelet</p>
                <div className="cl-pdp-pills">
                  {product.bracelets.map(b => (
                    <button 
                      key={b}
                      type="button"
                      className={`cl-pdp-pill ${selectedBracelet === b ? 'active' : ''}`}
                      onClick={() => setSelectedBracelet(b)}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>
            )}

            <div className="cl-pdp-actions">
              <input 
                type="number" 
                min={1} 
                value={quantity} 
                onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))} 
              />
              <button 
                type="button" 
                className="cl-pdp-btn cl-pdp-btn--outline" 
                onClick={handleAddToCart}
              >
                <CiShoppingBasket />
                Ajouter au panier
              </button>
              <button 
                type="button" 
                className="cl-pdp-btn cl-pdp-btn--solid" 
                onClick={handleBuyNow}
              >
                Acheter maintenant
              </button>
            </div>

            <button 
              type="button" 
              className="cl-pdp-wishlist"
              onClick={() => dispatch(toggleWishlist(product))}
              style={{ color: isInWishlist ? '#c87d08' : 'inherit' }}
            >
              <CiHeart />
              {isInWishlist ? 'Retirer de ma liste d\'envies' : 'Ajouter à ma liste d\'envies'}
            </button>
          </div>
        </div>
      </section>

      <section className="cl-collection">
        <div className="container">
          <div className='title-page'>
            <h2 className="cl-section-title">Montres Similaires</h2>
            <p className="cl-section-sub-title">Prolongez l’élégance avec des modèles qui vous ressemblent</p>
          </div>

          <div className="cl-collection-grid">
            {similarProducts.map((p) => (
              <div className="cl-product-card" key={p.id}>
                <div className="cl-product-img-wrap">
                  {p.isNew && <span className="cl-product-badge">New</span>}
                  <button 
                    type="button"
                    className="cl-product-heart"
                    onClick={() => dispatch(toggleWishlist(p))}
                  >
                    <CiHeart className="i" />
                  </button>
                  <img src={p.img} alt={p.name} className="cl-product-img" />
                </div>

                <div className="cl-product-info">
                  <h3 className="cl-product-name">{p.name}</h3>
                  <span className="cl-product-price">{p.price.toLocaleString('fr-FR')} XOF</span>

                  <div className="cl-product-actions">
                    <Link 
                      to="/produit-details" 
                      className="cl-product-discover"
                      onClick={() => {
                        dispatch(setSelectedProduct(p.id));
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                    >
                      Découvrir
                    </Link>
                    <button 
                      type="button" 
                      className="cl-product-cart-btn" 
                      aria-label="Ajouter au panier"
                      onClick={() => dispatch(addToCart(p))}
                    >
                      <CiShoppingBasket className="i" />
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  )
}