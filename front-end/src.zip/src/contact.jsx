import React, { useState } from 'react';
import { FaInstagram, FaFacebookF, FaTiktok, FaWhatsapp } from "react-icons/fa";

const API_BASE = "http://localhost:5000/api";

export default function Contact() {
    const [formData, setFormData] = useState({
        name: '',
        email: '',
        subject: '',
        message: ''
    });

    const [status, setStatus] = useState({ loading: false, success: null, message: '' });

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.id]: e.target.value });
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        setStatus({ loading: true, success: null, message: '' });

        try {
            const res = await fetch(`${API_BASE}/contact`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(formData)
            });
            const data = await res.json();

            if (res.ok && data.success) {
                setStatus({ loading: false, success: true, message: 'Votre message a bien été envoyé ! Nous vous répondrons sous 24h.' });
                setFormData({ name: '', email: '', subject: '', message: '' });
            } else {
                setStatus({ loading: false, success: false, message: data.message || "Une erreur est survenue." });
            }
        } catch (error) {
            setStatus({ loading: false, success: false, message: "Impossible de joindre le serveur pour le moment." });
        }
    };

    return (
        <div>
            <section className="cl-innerhero">
                <div className="container cl-innerhero-inner">
                    <h1 className="cl-innerhero-title">Nous <span>Contacter</span></h1>
                </div>
            </section>

            <section className="cl-contactus">
                <div className="container">
                    <div className='title-page'>
                        <h2 className="cl-section-title">Échangeons Ensemble</h2>
                        <p className="cl-section-sub-title">L’élégance commence par <span>une relation de confiance</span></p>
                    </div>

                    <div className="cl-contactus-grid">
                        <div className="cl-contactus-info">
                            <div className="cl-contactus-item">
                                <span className="cl-contactus-label">Email </span>
                                <p>centralluxecontact@gmail.com</p>
                            </div>

                            <div className="cl-contactus-item">
                                <span className="cl-contactus-label">Téléphone </span>
                                <p>+33 1 00 00 00 00</p>
                            </div>

                            <div className="cl-contactus-item">
                                <span className="cl-contactus-label">Localisation </span>
                                <p>14 rue de la Paix 75002 Paris, France</p>
                            </div>

                            <div>
                                <span className="cl-contactus-label">Follow us</span>
                                <div className="cl-contactus-socials">
                                    <a className="cl-contactus-social" target='_blank' rel="noreferrer" href="https://www.tiktok.com/@central.luxe"><FaTiktok /></a>
                                    <a className="cl-contactus-social" target='_blank' rel="noreferrer" href="https://wa.me/message/R4PMXGWSUYASJ1"><FaWhatsapp /></a>
                                    <a className="cl-contactus-social" target='_blank' rel="noreferrer" href="https://www.facebook.com/share/1EVFnjrzhC/"><FaFacebookF /></a>
                                    <a className="cl-contactus-social" target='_blank' rel="noreferrer" href="https://www.instagram.com/centralluxe1"><FaInstagram /></a>
                                </div>
                            </div>
                        </div>

                        <form className="cl-contactus-form" onSubmit={handleSubmit}>
                            {status.message && (
                                <div style={{
                                    padding: '12px 16px',
                                    borderRadius: '6px',
                                    background: status.success ? 'rgba(46, 125, 50, 0.15)' : 'rgba(211, 47, 47, 0.15)',
                                    color: status.success ? '#2e7d32' : '#d32f2f',
                                    border: `1px solid ${status.success ? '#2e7d32' : '#d32f2f'}`,
                                    fontSize: '14px',
                                    fontFamily: 'Sora, sans-serif'
                                }}>
                                    {status.message}
                                </div>
                            )}

                            <div className="cl-contactus-row">
                                <div className="cl-contactus-field">
                                    <label htmlFor="name">Nom & Prénoms</label>
                                    <input 
                                        id="name" 
                                        type="text" 
                                        required 
                                        value={formData.name}
                                        onChange={handleChange}
                                        placeholder="Votre nom complet" 
                                    />
                                </div>
                                <div className="cl-contactus-field">
                                    <label htmlFor="email">Adresse email</label>
                                    <input 
                                        id="email" 
                                        type="email" 
                                        required 
                                        value={formData.email}
                                        onChange={handleChange}
                                        placeholder="Votre adresse email" 
                                    />
                                </div>
                            </div>
                            <div className="cl-contactus-field">
                                <label htmlFor="subject">Votre sujet</label>
                                <input 
                                    id="subject" 
                                    type="text" 
                                    value={formData.subject}
                                    onChange={handleChange}
                                    placeholder="Le sujet de votre message" 
                                />
                            </div>
                            <div className="cl-contactus-field">
                                <label htmlFor="message">Message</label>
                                <textarea 
                                    id="message" 
                                    required
                                    value={formData.message}
                                    onChange={handleChange}
                                    placeholder="Votre message" 
                                />
                            </div>

                            <button type="submit" className="cl-contactus-submit" disabled={status.loading}>
                                {status.loading ? 'Envoi en cours...' : 'Envoyer le message'}
                            </button>
                        </form>
                    </div>
                </div>
            </section>
        </div>
    );
}