// src/panier.jsx
import React, { useState } from 'react';
import { FaTrashAlt } from "react-icons/fa";
import './App.css';
import { Link } from 'react-router-dom';
import { IoIosClose } from "react-icons/io";
import { useSelector, useDispatch } from 'react-redux';
import { 
    selectCartItems, 
    updateQty, 
    updateVariant, 
    removeFromCart, 
    clearCart,
    selectCartSubtotal 
} from './redux/cartSlice';

const API_BASE = "http://localhost:5000/api";

const VALID_PROMO_CODES = {
    'LUXE10': 0.10,
    'BIENVENUE': 0.15,
    'PROMO20': 0.20
};

export default function Panier() {
    const dispatch = useDispatch();
    const cartItems = useSelector(selectCartItems);
    const subtotal = useSelector(selectCartSubtotal);

    // Code promo
    const [promoInput, setPromoInput] = useState('');
    const [appliedCode, setAppliedCode] = useState('');
    const [appliedDiscountRate, setAppliedDiscountRate] = useState(0);
    const [promoMessage, setPromoMessage] = useState(null);

    // Modal commande
    const [isCheckoutModalOpen, setIsCheckoutModalOpen] = useState(false);
    const [customer, setCustomer] = useState({
        name: '',
        phone: '',
        email: '',
        address: '',
        notes: ''
    });
    const [orderStatus, setOrderStatus] = useState({ loading: false, error: null, successOrderNum: null });

    const handleApplyPromo = () => {
        const cleanCode = promoInput.trim().toUpperCase();
        if (VALID_PROMO_CODES[cleanCode]) {
            setAppliedDiscountRate(VALID_PROMO_CODES[cleanCode]);
            setAppliedCode(cleanCode);
            setPromoMessage({ type: 'success', text: `Code ${cleanCode} appliqué (-${VALID_PROMO_CODES[cleanCode] * 100}%)` });
        } else {
            setPromoMessage({ type: 'error', text: 'Code promo invalide' });
        }
    };

    const discountAmount = Math.round(subtotal * appliedDiscountRate);
    const total = Math.max(0, subtotal - discountAmount);

    const handleOrderSubmit = async (e) => {
        e.preventDefault();
        setOrderStatus({ loading: true, error: null, successOrderNum: null });

        try {
            const res = await fetch(`${API_BASE}/orders`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    customer,
                    items: cartItems,
                    subtotal,
                    discount: discountAmount,
                    promoCode: appliedCode,
                    total
                })
            });

            const data = await res.json();
            if (res.ok && data.success) {
                setOrderStatus({ loading: false, error: null, successOrderNum: data.orderNumber });
                dispatch(clearCart());
            } else {
                setOrderStatus({ loading: false, error: data.message || "Erreur lors de la commande", successOrderNum: null });
            }
        } catch {
            setOrderStatus({ loading: false, error: "Serveur inaccessible. Veuillez réessayer.", successOrderNum: null });
        }
    };

    return (
        <div>
            <section className="cl-innerhero">
                <div className="container cl-innerhero-inner">
                    <h1 className="cl-innerhero-title">Mon<span> Panier</span></h1>
                </div>
            </section>

            <section className="cart">
                <div className="container">
                    <div className="cl-cart">
                        <div className="cl-cart-items">
                            <div className="cl-cart-head">
                                <h2 className="cl-cart-title">
                                    Panier <sup>{String(cartItems.length).padStart(2, '0')}</sup>
                                </h2>
                                {cartItems.length > 0 && (
                                    <button 
                                        className="cl-cart-clear" 
                                        onClick={() => dispatch(clearCart())} 
                                        aria-label="Vider le panier"
                                    >
                                        <FaTrashAlt />
                                    </button>
                                )}
                            </div>

                            {cartItems.length === 0 ? (
                                <div className="cl-cart-empty">
                                    <p>Votre panier est actuellement vide.</p>
                                    <Link to="/boutique" className="cl-cart-checkout">
                                        Découvrir la boutique
                                    </Link>
                                </div>
                            ) : (
                                cartItems.map((item) => (
                                    <div className="cl-cart-item" key={item.cartItemId}>
                                        <div className="cl-cart-item-img">
                                            <img src={item.img} alt={item.name} />
                                        </div>

                                        <div className="cl-cart-item-body">
                                            <span className="cl-cart-item-tag">{item.tag}</span>
                                            <p className="cl-cart-item-name">{item.name}</p>

                                            <div className="cl-cart-item-variants">
                                                <label className="cl-cart-select-wrap">
                                                    Couleur :
                                                    <select
                                                        value={item.bracelet}
                                                        onChange={(e) => dispatch(updateVariant({
                                                            cartItemId: item.cartItemId,
                                                            field: 'bracelet',
                                                            value: e.target.value
                                                        }))}
                                                    >
                                                        {item.braceletOptions?.map((opt) => (
                                                            <option key={opt} value={opt}>{opt}</option>
                                                        ))}
                                                    </select>
                                                </label>

                                                {item.tailleOptions?.length > 0 && (
                                                    <label className="cl-cart-select-wrap">
                                                        Taille :
                                                        <select
                                                            value={item.taille}
                                                            onChange={(e) => dispatch(updateVariant({
                                                                cartItemId: item.cartItemId,
                                                                field: 'taille',
                                                                value: e.target.value
                                                            }))}
                                                        >
                                                            {item.tailleOptions.map((opt) => (
                                                                <option key={opt} value={opt}>{opt}</option>
                                                            ))}
                                                        </select>
                                                    </label>
                                                )}
                                            </div>
                                        </div>

                                        <div className="cl-cart-item-right">
                                            <div className="cl-cart-item-icons">
                                                <button 
                                                    aria-label="Supprimer" 
                                                    onClick={() => dispatch(removeFromCart(item.cartItemId))}
                                                >
                                                    <IoIosClose />
                                                </button>
                                            </div>
                                            <div className="cl-cart-item-bottom">
                                                <div className="cl-cart-qty">
                                                    <button onClick={() => dispatch(updateQty({ cartItemId: item.cartItemId, delta: -1 }))}>−</button>
                                                    <span>{item.qty}</span>
                                                    <button onClick={() => dispatch(updateQty({ cartItemId: item.cartItemId, delta: 1 }))}>+</button>
                                                </div>
                                                <span className="cl-cart-item-price">{(item.price * item.qty).toLocaleString('fr-FR')} XOF</span>
                                            </div>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>

                        <div className="cl-cart-summary">
                            <h2 className="cl-cart-summary-title">Récapitulatif</h2>
                            <div className="cl-cart-summary-box">
                                <div className="cl-cart-summary-row">
                                    <span>Articles sélectionnés</span>
                                    <span>{String(cartItems.length).padStart(2, '0')} articles</span>
                                </div>
                                <div className="cl-cart-summary-row">
                                    <span>Sous-total</span>
                                    <span>{subtotal.toLocaleString('fr-FR')} XOF</span>
                                </div>
                                <div className="cl-cart-summary-row">
                                    <span>Livraison estimée</span>
                                    <span>Offerte</span>
                                </div>
                                <div className="cl-cart-summary-row">
                                    <span>Remise</span>
                                    <span>{discountAmount > 0 ? `−${discountAmount.toLocaleString('fr-FR')} XOF` : '−0 XOF'}</span>
                                </div>

                                <hr className="cl-cart-summary-divider" />

                                <div className="cl-cart-summary-total">
                                    <span>Total à payer</span>
                                    <span>{total.toLocaleString('fr-FR')} XOF</span>
                                </div>

                                <div className="cl-cart-promo">
                                    <input 
                                        type="text" 
                                        placeholder="Code promo (ex: LUXE10)" 
                                        value={promoInput}
                                        onChange={(e) => setPromoInput(e.target.value)}
                                        disabled={cartItems.length === 0} 
                                    />
                                    <button 
                                        type="button"
                                        className="cl-cart-promo-btn" 
                                        disabled={cartItems.length === 0}
                                        onClick={handleApplyPromo}
                                    >
                                        Appliquer
                                    </button>
                                </div>

                                {promoMessage && (
                                    <p style={{
                                        fontSize: '12px',
                                        marginTop: '-10px',
                                        marginBottom: '14px',
                                        color: promoMessage.type === 'success' ? '#2e7d32' : '#d32f2f',
                                        fontFamily: 'Sora, sans-serif'
                                    }}>
                                        {promoMessage.text}
                                    </p>
                                )}

                                <button 
                                    type="button"
                                    className={`cl-cart-checkout-alt ${cartItems.length === 0 ? 'disabled' : ''}`}
                                    disabled={cartItems.length === 0}
                                    onClick={() => setIsCheckoutModalOpen(true)}
                                    style={{ width: '100%', cursor: cartItems.length === 0 ? 'not-allowed' : 'pointer' }}
                                >
                                    Passer la commande
                                </button>
                                <Link to="/boutique" className="cl-cart-checkout">Continuer mes achats</Link>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            {/* MODAL COMMANDE */}
            {isCheckoutModalOpen && (
                <div style={{
                    position: 'fixed',
                    inset: 0,
                    backgroundColor: 'rgba(0,0,0,0.85)',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    zIndex: 9999,
                    padding: '20px'
                }} className='modal-panier'>
                    <div style={{
                        background: '#ffffff',
                        borderRadius: '16px',
                        maxWidth: '520px',
                        width: '100%',
                        padding: '30px',
                        position: 'relative',
                        maxHeight: '90vh',
                        overflowY: 'auto'
                    }} className='content-panier'>
                        <button 
                            type="button"
                            onClick={() => {
                                setIsCheckoutModalOpen(false);
                                setOrderStatus({ loading: false, error: null, successOrderNum: null });
                            }}
                            style={{
                                position: 'absolute',
                                top: '20px',
                                right: '20px',
                                background: 'transparent',
                                border: 'none',
                                fontSize: '24px',
                                cursor: 'pointer'
                            }}
                        >
                            <IoIosClose />
                        </button>

                        {orderStatus.successOrderNum ? (
                            <div style={{ textAlign: 'center', padding: '20px 0' }}>
                                <h3 style={{ color: '#c87d08', fontFamily: 'Montserrat, sans-serif', fontSize: '24px' }}>
                                    Commande Confirmée !
                                </h3>
                                <p style={{ fontFamily: 'Sora, sans-serif', fontSize: '15px', color: '#444', margin: '15px 0' }}>
                                    Merci pour votre commande n° <strong>{orderStatus.successOrderNum}</strong>.
                                    Un récapitulatif détaillé vous a été envoyé par email. Notre équipe vous contactera sous peu pour finaliser la livraison.
                                </p>
                                <button
                                    className="cl-hero-cta"
                                    onClick={() => {
                                        setIsCheckoutModalOpen(false);
                                        setOrderStatus({ loading: false, error: null, successOrderNum: null });
                                    }}
                                >
                                    Fermer
                                </button>
                            </div>
                        ) : (
                            <form onSubmit={handleOrderSubmit}>
                                <h3 style={{ fontFamily: 'Montserrat, sans-serif', fontSize: '22px', marginBottom: '8px' }}>
                                    Finaliser votre commande
                                </h3>
                                <p style={{ fontFamily: 'Sora, sans-serif', fontSize: '13px', color: '#666', marginBottom: '20px' }}>
                                    Montant total : <strong>{total.toLocaleString('fr-FR')} XOF</strong>
                                </p>

                                {orderStatus.error && (
                                    <div style={{ color: '#d32f2f', fontSize: '13px', marginBottom: '14px' }}>
                                        {orderStatus.error}
                                    </div>
                                )}

                                <div className="cl-contactus-field" style={{ marginBottom: '14px' }}>
                                    <label>Nom complet *</label>
                                    <input 
                                        type="text" 
                                        required 
                                        placeholder="Ex: Jean Dupont"
                                        value={customer.name}
                                        onChange={(e) => setCustomer({ ...customer, name: e.target.value })}
                                    />
                                </div>

                                <div className="cl-contactus-field" style={{ marginBottom: '14px' }}>
                                    <label>Numéro de Téléphone (WhatsApp de préférence) *</label>
                                    <input 
                                        type="tel" 
                                        required 
                                        placeholder="Ex: +229 97 00 00 00"
                                        value={customer.phone}
                                        onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                                    />
                                </div>

                                <div className="cl-contactus-field" style={{ marginBottom: '14px' }}>
                                    <label>Email (pour recevoir le reçu)</label>
                                    <input 
                                        type="email" 
                                        placeholder="Ex: jean.dupont@email.com"
                                        value={customer.email}
                                        onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
                                    />
                                </div>

                                <div className="cl-contactus-field" style={{ marginBottom: '14px' }}>
                                    <label>Ville & Quartier de livraison *</label>
                                    <input 
                                        type="text" 
                                        required 
                                        placeholder="Ex: Cotonou, Haie Vive"
                                        value={customer.address}
                                        onChange={(e) => setCustomer({ ...customer, address: e.target.value })}
                                    />
                                </div>

                                <div className="cl-contactus-field" style={{ marginBottom: '20px' }}>
                                    <label>Note additionnelle (optionnelle)</label>
                                    <textarea 
                                        placeholder="Précisions pour la livraison..."
                                        style={{ minHeight: '70px' }}
                                        value={customer.notes}
                                        onChange={(e) => setCustomer({ ...customer, notes: e.target.value })}
                                    />
                                </div>

                                <button 
                                    type="submit" 
                                    className="cl-wish-checkout"
                                    disabled={orderStatus.loading}
                                >
                                    {orderStatus.loading ? 'Envoi en cours...' : `Confirmer la commande`}
                                </button>
                            </form>
                        )}
                    </div>
                </div>
            )}
        </div>
    );
}