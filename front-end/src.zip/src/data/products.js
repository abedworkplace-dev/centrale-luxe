// src/data/products.js
import watchGold from "../assets/images/02.png";
import watchSilver from "../assets/images/01.png";

export const initialProducts = [
  {
    id: 1,
    name: 'Chronos Élégance',
    price: 12000,
    img: watchGold,
    images: [watchGold, watchSilver, watchGold, watchSilver],
    tag: 'Or Rose',
    stock: true,
    isNew: true,
    rating: 5,
    reviews: 120,
    description: "Des montres façonnées avec des matériaux soignés, alliant élégance intemporelle et précision horlogère pour accompagner chaque instant de votre journée.",
    colors: [
      { id: 'gold', hex: '#F2D16B', label: 'Or Rose' },
      { id: 'silver', hex: '#cfd0d2', label: 'Argent' },
      { id: 'black', hex: '#111111', label: 'Noir' }
    ],
    bracelets: ['Cuir marron', 'Cuir noir', 'Acier'],
    tailles: ['36 mm', '40 mm']
  },
  {
    id: 2,
    name: 'Chronos Sport',
    price: 15500,
    img: watchSilver,
    images: [watchSilver, watchGold, watchSilver, watchGold],
    tag: 'Acier',
    stock: true,
    isNew: false,
    rating: 5,
    reviews: 98,
    description: "Pensée pour les esprits dynamiques, alliant robustesse et raffinement.",
    colors: [
      { id: 'silver', hex: '#cfd0d2', label: 'Argent' },
      { id: 'black', hex: '#111111', label: 'Noir' }
    ],
    bracelets: ['Acier', 'Maille milanaise'],
    tailles: ['40 mm', '42 mm']
  },
  {
    id: 3,
    name: 'Le Méridien Or',
    price: 18000,
    img: watchGold,
    images: [watchGold, watchSilver],
    tag: 'Édition Spéciale',
    stock: true,
    isNew: true,
    rating: 4,
    reviews: 64,
    description: "Édition limitée au boîtier ultra fin et mouvement automatique d'une grande précision.",
    colors: [
      { id: 'gold', hex: '#F2D16B', label: 'Or Rose' }
    ],
    bracelets: ['Cuir marron', 'Acier'],
    tailles: ['38 mm', '40 mm']
  },
  {
    id: 4,
    name: 'Chronos Classic Noir',
    price: 14000,
    img: watchSilver,
    images: [watchSilver, watchGold],
    tag: 'Cuir',
    stock: false, // Rupture de stock de test pour la wishlist
    isNew: false,
    rating: 5,
    reviews: 140,
    description: "L'élégance sobre au poignet avec cadran sombre et bracelet surpiqué.",
    colors: [
      { id: 'black', hex: '#111111', label: 'Noir' },
      { id: 'silver', hex: '#cfd0d2', label: 'Argent' }
    ],
    bracelets: ['Cuir noir', 'Cuir marron'],
    tailles: ['40 mm']
  },
  {
    id: 5,
    name: 'Chronos Prestige Gold',
    price: 22000,
    img: watchGold,
    images: [watchGold, watchSilver],
    tag: 'Luxe',
    stock: true,
    isNew: true,
    rating: 5,
    reviews: 45,
    description: "Modèle de haute horlogerie, finitions satinées et polies à la main.",
    colors: [
      { id: 'gold', hex: '#F2D16B', label: 'Or Rose' }
    ],
    bracelets: ['Acier', 'Maille milanaise'],
    tailles: ['40 mm']
  },
  {
    id: 6,
    name: 'Chronos Aviateur',
    price: 16500,
    img: watchSilver,
    images: [watchSilver, watchGold],
    tag: 'Acier brossé',
    stock: true,
    isNew: false,
    rating: 4,
    reviews: 82,
    description: "Inspirée des chronographes de bord d'aviation militaire.",
    colors: [
      { id: 'silver', hex: '#cfd0d2', label: 'Argent' }
    ],
    bracelets: ['Cuir marron', 'Acier'],
    tailles: ['42 mm']
  }
];