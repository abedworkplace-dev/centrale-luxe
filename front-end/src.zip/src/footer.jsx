import { useState } from 'react';
import { FaInstagram, FaFacebookF, FaTiktok, FaWhatsapp } from "react-icons/fa";
import { HiOutlineChevronRight } from "react-icons/hi";

const API_BASE = "http://localhost:5000/api";

export default function Footer() {
    const [email, setEmail] = useState('');
    const [subMessage, setSubMessage] = useState(null);
    const [loading, setLoading] = useState(false);

    const handleSubscribe = async (e) => {
        e.preventDefault();
        if (!email) return;

        setLoading(true);
        setSubMessage(null);

        try {
            const res = await fetch(`${API_BASE}/newsletter`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email })
            });
            const data = await res.json();

            if (res.ok && data.success) {
                setSubMessage({ type: 'success', text: 'Bienvenue ! Vérifiez votre boîte mail.' });
                setEmail('');
            } else {
                setSubMessage({ type: 'error', text: data.message || "Erreur lors de l'inscription." });
            }
        } catch {
            setSubMessage({ type: 'error', text: 'Erreur réseau.' });
        } finally {
            setLoading(false);
        }
    };

    return (
        <div>
            <footer className="cl-footer">
                <div className="container cl-footer-inner">
                    <div className="cl-footer-grid">
                        <div>
                            <div className="cl-footer-logo">
                                <img alt="Central Luxe" src="/src/assets/images/logo/01.png" />
                            </div>
                            <p className="cl-footer-tagline">
                                Des montres pensées pour durer, vendues sans intermédiaire.
                            </p>
                            <div className="cl-footer-social">
                                <a target='_blank' rel="noreferrer" href="https://www.tiktok.com/@central.luxe"><FaTiktok /></a>
                                <a target='_blank' rel="noreferrer" href="https://wa.me/message/R4PMXGWSUYASJ1"><FaWhatsapp /></a>
                                <a target='_blank' rel="noreferrer" href="https://www.facebook.com/share/1EVFnjrzhC/"><FaFacebookF /></a>
                                <a target='_blank' rel="noreferrer" href="https://www.instagram.com/centralluxe1"><FaInstagram /></a>
                            </div>
                        </div>

                        <div>
                            <p className="cl-footer-heading">Nous contacter</p>
                            <div className="cl-footer-contact">
                                <p><a href="mailto:centralluxecontact@gmail.com">centralluxecontact@gmail.com</a></p>
                                <p>14 rue de la Paix 75002 Paris, France</p>
                                <p><a href="tel:+33100000000">+33 1 00 00 00 00</a></p>
                            </div>
                        </div>

                        <div>
                            <p className="cl-footer-heading">Newsletter</p>
                            <p className="cl-footer-news-text">
                                Recevez nos nouveautés et offres réservées à nos abonnés.
                            </p>
                            <form className="cl-footer-news-form" onSubmit={handleSubscribe}>
                                <input 
                                    type="email" 
                                    placeholder="Votre email" 
                                    value={email}
                                    onChange={(e) => setEmail(e.target.value)}
                                    required
                                />
                                <button className="cl-footer-news-btn" type="submit" disabled={loading} aria-label="S'abonner">
                                    <HiOutlineChevronRight />
                                </button>
                            </form>
                            {subMessage && (
                                <p style={{
                                    fontSize: '12px',
                                    marginTop: '8px',
                                    color: subMessage.type === 'success' ? '#c87d08' : '#e57373',
                                    fontFamily: 'Sora, sans-serif'
                                }}>
                                    {subMessage.text}
                                </p>
                            )}
                        </div>
                    </div>

                    <div className="cl-footer-bottom">
                        <div className="cl-footer-legal">
                            <p className="cl-footer-copyright">Designed & developed by <a href="#">AbedDev</a></p>
                        </div>
                        <p className="cl-footer-copyright">© 2026 Central Luxe. Tous droits réservés.</p>
                    </div>
                </div>
            </footer>
        </div>
    );
}